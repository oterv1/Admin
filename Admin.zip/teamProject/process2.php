<?php

session_start();
  // Password and User Changerd
 $mysqli = new mysqli('localhost','admin','Pa11word','deltaTeam') or die(mysqli_error($mysqli));
  
  $room_id=0;
  $update= false;
  $room_no=0;
  $capacity=0;
  $BuildingID=0;
  
 if (isset($_POST['add'])){
	 $room_no= $_POST['room_no'];
	 $capacity=$_POST['capacity'];
	 $BuildingID = $_POST['BuildingID'];
	
	 
	 $mysqli->query("INSERT IGNORE INTO rooms_info (room_no,capacity,BuildingID) VALUES ('$room_no','$capacity','$BuildingID')") or
	                die($mysqli->error);
		
		
			
    $_SESSION['message']="Record has been Added!";
	$_SESSION['msg_type']= "success";
	
	header("location: table_2.php");
 }
  
  if (isset($_GET['delete'])){
	  $room_id= $_GET['delete'];
	  $mysqli->query("DELETE FROM rooms_info WHERE room_id=$room_id") or die($mysqli->error());
	  
	  $_SESSION['message']="Record has been Deleted!";
	  $_SESSION['msg_type']= "danger";
	  
	  header("location: table_2.php");
  }
  
  
  if (isset($_GET['edit'])){
	  $room_id = $_GET['edit'];
	  $update = true;
	  $result = $mysqli->query("SELECT * FROM rooms_info WHERE room_id=$room_id") or die($mysqli->error);
	  
	  while($row = mysqli_fetch_array($result)){
		 
		  $room_no = $row['room_no'];
		  $capacity= $row['capacity'];
		  $BuildingID = $row['BuildingID'];
	  }
	  
  }
  
  if (isset($_POST['update'])){
	  $room_id = $_POST['room_id'];
	  $room_no = $_POST['room_no'];
	  $capacity = $_POST['capacity'];
	  
	  
	  $mysqli->query("UPDATE rooms_info SET room_no='$room_no', capacity='$capacity' WHERE room_id=$room_id")or
	                 die($mysqli->error);
					 
	 $_SESSION['message']="Record has been Updated!";
	  $_SESSION['msg_type']= "warning";
	  
	  header("location: table_2.php");
  }

?>