
<?php
  // Password and User Changerd
 $db = mysqli_connect("localhost","admin","Pa11word","deltateam");
 $sql = "SELECT * FROM building_info INNER JOIN rooms_info ON building_info.BuildingID = rooms_info.BuildingID";
 $result = mysqli_query($db,$sql);
?>




<!DOCTYPE html>
 <html>
  <head>
   
   <title>Delta Home</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
   
   </style>
  </head>
  <body>
   <br/>
    <div class="container" style="width:600px">
    <h1 class="text-center">Report of Buildings and Rooms</h1><br/>
	
	
    
	 <div class="table-responsive">
	  <table class="table table-striped">
	    <tr>
		   <th>Building ID</th>
		   <th>Building Number</th>
		   <th>Building Name</th>
		   <th>Room ID</th>
		   <th>Room Number</th>
		   <th>Capacity</th>
		</tr>
		<?php
		if(mysqli_num_rows($result) > 0)
		{
			while($row = mysqli_fetch_array($result))
			{
			?>
			
				<tr>
				  <td><?php echo $row['BuildingID']; ?></td>
				  <td><?php echo $row['BuildingNO']; ?></td>
				  <td><?php echo $row['BuildingName']; ?></td>
				  <td><?php echo $row['room_id']; ?></td>
				  <td><?php echo $row['room_no']; ?></td>
				  <td><?php echo $row['capacity']; ?></td>
				</tr>
				<?php 
			}
		}
		?>
	  </table>
	 </div>
	 <br>
	  <?php
     // Password and User Changerd
 $connect = mysqli_connect("localhost","admin","Pa11word","deltateam");
 
 $sqli = "SELECT rooms_info.room_id, room_comp.count, comp_info.model, comp_info.memory_size, comp_info.storage_size,
        vendor_info.name FROM room_comp JOIN rooms_info ON room_comp.room_id = rooms_info.room_id JOIN
		comp_info ON room_comp.comp_id = comp_info.comp_id JOIN vendor_info ON comp_info.vendor_id = vendor_info.vendor_id";
 
 $results = mysqli_query($connect,$sqli)
?>


    <div class="container" style="width:800px">
    <h3 class="text-center">Room ID, Vendor, Computer Info and Quantity</h3><br/>
	
	
    
	 <div class="table-responsive">
	  <table class="table table-striped">
	    <tr>
		   <th>Room ID</th>
		   <th>Vendor's Name</th>
		   <th>Computer Model</th>
		   <th>Memory Size</th>
		   <th>Storage Size</th>
		   <th>Number of Computers</th>
		</tr>
		<?php
		if(mysqli_num_rows($results) > 0)
		{
			while($row = mysqli_fetch_array($results))
			{
			?>
			
				<tr>
				  <td><?php echo $row['room_id']; ?></td>
				  <td><?php echo $row['name']; ?></td>
				  <td><?php echo $row['model']; ?></td>
				  <td><?php echo $row['memory_size']; ?></td>
				  <td><?php echo $row['storage_size']; ?></td>
				  <td><?php echo $row['count']; ?></td>
				</tr>
				<?php 
			}
		}
		?>
	  </table>
	 </div>
	 
	 

	 <br/>
	 <br/>
	 <div class="text-center">
	   <a href="index.php" class="btn btn-info text-center" align="center">Home</a>
	 </div>

   </body>
   
  </html>
       	   