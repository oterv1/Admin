<!DOCTYPE html>
 <html>
  <head>
   
   <title>Delta Home</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
   
   </style>
  </head>
  <body>
    <h1 class="text-center">Delta Home Page</h1><br/>
	<h3 class="text-center">Select the Table You Want View.</h3><br/>
	<br/><br/>
    
				<div class="text-center"> 
				  <a href="table_1.php" class="btn btn-info">Building Table</a>
				  
				  <a href="table_2.php" class="btn btn-info">Room Table</a>
				  
				  <a href="table_5.php" class="btn btn-info">Vendor Table</a>
				  
				  <a href="table_4.php" class="btn btn-info">Computers Table</a>
				  
				  <a href="table_3.php" class="btn btn-info">Numbers of Computers Table</a>
				 </div><br/><br/>
				 
				 <div class="text-center"> 
				  <a href="report.php" class="btn btn-info">Report Table</a>
				  
				  
				 </div>

   </body>
   
  </html>
       	   