<?php

session_start();
 // Password and User Changerd 
 $mysqli = new mysqli('localhost','admin','Pa11word','deltaTeam') or die(mysqli_error($mysqli));
  
  $BuildingID=0;
  $update= false;
  $BuildingNO=0;
  $BuildingName='';
  
 if (isset($_POST['add'])){
	 $BuildingNO= $_POST['BuildingNO'];
	 $BuildingName=$_POST['BuildingName'];
	 
	 $mysqli->query("INSERT INTO building_info (BuildingNO,BuildingName) VALUES ('$BuildingNO','$BuildingName')") or
	                die($mysqli->error());
					
    $_SESSION['message']="Record has been Added!";
	$_SESSION['msg_type']= "success";
	
	header("location: table_1.php");
 }
  
  if (isset($_GET['delete'])){
	  $BuildingID= $_GET['delete'];
	  $mysqli->query("DELETE FROM building_info WHERE BuildingID=$BuildingID") or die($mysqli->error());
	  
	  $_SESSION['message']="Record has been Deleted!";
	  $_SESSION['msg_type']= "danger";
	  
	  header("location: table_1.php");
  }
  
  
  if (isset($_GET['edit'])){
	  $BuildingID = $_GET['edit'];
	  $update = true;
	  $result = $mysqli->query("SELECT * FROM building_info WHERE BuildingID=$BuildingID") or die($mysqli->error());
	  
	 while($row = mysqli_fetch_array($result)) {
		 
		  $BuildingNO = $row['BuildingNO'];
		  $BuildingName= $row['BuildingName'];
	  }
	  
  }
  
  if (isset($_POST['update'])){
	  $BuildingID = $_POST['BuildingID'];
	  $BuildingNO = $_POST['BuildingNO'];
	  $BuildingName = $_POST['BuildingName'];
	  
	  $mysqli->query("UPDATE building_info SET BuildingNO='$BuildingNO', BuildingName='$BuildingName' WHERE BuildingID=$BuildingID")or
	                 die($mysqli->error());
					 
	 $_SESSION['message']="Record has been Updated!";
	  $_SESSION['msg_type']= "warning";
	  
	  header("location: table_1.php");
  }

?>