<?php

session_start();
// Password and User Changerd
 $mysqli = new mysqli('localhost','admin','Pa11word','deltaTeam') or die(mysqli_error($mysqli));
  
  $vendor_id=0;
  $update= false;
  $name='';
  $contact='';
  $phone = '';
  
 if (isset($_POST['add'])){
	 $name= $_POST['name'];
	 $contact=$_POST['contact'];
	 $phone = $_POST['phone'];
	 
	 $mysqli->query("INSERT INTO vendor_info (name,contact,phone) VALUES ('$name','$contact','$phone')") or
	                die($mysqli->error());
					
    $_SESSION['message']="Record has been Added!";
	$_SESSION['msg_type']= "success";
	
	header("location: table_5.php");
 }
  
  if (isset($_GET['delete'])){
	  $vendor_id= $_GET['delete'];
	  $mysqli->query("DELETE FROM vendor_info WHERE vendor_id=$vendor_id") or die($mysqli->error());
	  
	  $_SESSION['message']="Record has been Deleted!";
	  $_SESSION['msg_type']= "danger";
	  
	  header("location: table_5.php");
  }
  
  
  if (isset($_GET['edit'])){
	  $vendor_id = $_GET['edit'];
	  $update = true;
	  $result = $mysqli->query("SELECT * FROM vendor_info WHERE vendor_id=$vendor_id") or die($mysqli->error());
	  
	  while($row = mysqli_fetch_array($result))
	  {
		  $name = $row['name'];
		  $contact= $row['contact'];
		  $phone = $row['phone'];
	  }
	  
  }
  
  if (isset($_POST['update'])){
	  $vendor_id = $_POST['vendor_id'];
	  $name = $_POST['name'];
	  $contact = $_POST['contact'];
	  $phone = $_POST['phone'];
	  
	  $mysqli->query("UPDATE vendor_info SET name='$name', contact='$contact',phone='$phone' WHERE vendor_id=$vendor_id")or
	                 die($mysqli->error());
					 
	 $_SESSION['message']="Record has been Updated!";
	  $_SESSION['msg_type']= "warning";
	  
	  header("location: table_5.php");
  }

?>