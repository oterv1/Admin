<!DOCTYPE html>
 <html>
  <head>
   
   <title>Table 2</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
	
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
  </head>
  <body>
    <h1 class="text-center">Rooms Information</h1>
	
	<p><?php
   // Password and User Changerd
$mysqli = new mysqli('localhost','admin','Pa11word','deltaTeam');
$query = mysqli_query($mysqli,"SELECT * FROM rooms_info");
if (mysqli_num_rows($query) < 1) {

    print "This record does not exist";
}
?></p>

    <?php require_once 'process2.php'; ?>
	
	<?php if (isset($_SESSION['message'])): ?>
	   <div class="alert alert-<?=$_SESSION['msg_type']?>">
	   
	      <?php
		   echo $_SESSION['message'];
		   unset($_SESSION['message']);
	       ?>
	   </div>
	   <?php endif ?>
	
	  <div class="container">
	<?php
	    $mysqli = new mysqli('localhost','root','vlad07','deltaTeam') or die(mysqli_error($mysqli));
		$result = $mysqli ->query("SELECT * FROM rooms_info") or die($mysqli->error);
	?>

	
	<div class="row justify-content-center">	
	    <table class="table">
		   <thead>
		     <tr>
			   <th>Room Number</th>
			   <th>Capacity</th>
			   <th colspan="2">Action</th>
			 </tr>
		   </thead>
		   <?php while($row = $result->fetch_assoc()): ?>
		    <tr>
			   <td><?php echo $row['room_no'] ?></td>
			   <td><?php echo $row['capacity'] ?></td>
			   <td>
			     <a href="table_2.php?edit=<?php echo $row['room_id']; ?>"
				 class="btn btn-info">Edit</a>
				 
				  <a href="process2.php?delete=<?php echo $row['room_id']; ?>"
				 class="btn btn-danger">Delete</a>
				 
			   </td>
			</tr>
			<?php endwhile; ?>
		</table>
	</div>
	
	<?php
	   function pre_r( $array ){
		   echo 'pre';
		   print_r($array);
		   echo '</pre>';
	   }
	?>
	
	
    <div class="row justify-content-center">
     <form  action="process2.php" method="POST">
	 
	   <input type="hidden" name="room_id"  value="<?php echo $room_id; ?>" >
	 
	   <div class="form-group">
	   <label>Room Number</label>
       <input type="text" name="room_no" class="form-control" value="<?php echo $room_no; ?>" placeholder="Enter Room Number">
	   </div>
	   
	   <div class="form-group">
	   <label>Capacity</label>
	   <input type="text" name="capacity" class="form-control" value="<?php echo $capacity; ?>" placeholder="Enter Capacity">
	   </div>
	     
	     <?php  
		 $sql = "SELECT * FROM building_info";
         $result = mysqli_query($mysqli, $sql);
         ?>
		 
		 <div class="form-group">
	     <label>BuildingID</label>
            <select id="BuildingID" name="BuildingID">
             <option value = ""></option>
        <?php
		
          while($row = mysqli_fetch_array($result)) {
          echo '<option value='.$row['BuildingID'].'>'.$row['BuildingID'].'</option>';
		  
          }
        ?> 
           </select>
        </div>
	   
	   <div class="form-group">
	   
	   <?php if($update== true): ?>
	   
	   <button type="submit" class="btn btn-info" name="update">Update</button>
	   
	   <?php else: ?>
	   <button type="submit" class="btn btn-primary" name="add">Add</button>
	   
	   <?php endif; ?>
	   </div>
	   
	 </form>
	</div>
	</div>
	<br/><br/><br/><br/>
	<a href="index.php" class="btn btn-info" align="text-center">Home</a>
   </body>
   
  </html>
       	   