<?php

session_start();
// Password and User Changerd
 $mysqli = new mysqli('localhost','admin','Pa11word','deltaTeam') or die(mysqli_error($mysqli));
  
  $comp_id=0;
  $update= false;
  $vendor_id=0;
  $model='';
  $memory_size='';
  $storage_size='';
  
 if (isset($_POST['add'])){
	 $model= $_POST['model'];
	 $memory_size=$_POST['memory_size'];
	 $storage_size=$_POST['storage_size'];
	 $vendor_id =$_POST['vendor_id'];
	 
	 $mysqli->query("INSERT IGNORE INTO comp_info (model,memory_size,storage_size,vendor_id) VALUES ('$model','$memory_size','$storage_size','$vendor_id')") or
	                die($mysqli->error());
					
    $_SESSION['message']="Record has been Added!";
	$_SESSION['msg_type']= "success";
	
	header("location: table_4.php");
 }
  
  if (isset($_GET['delete'])){
	  $comp_id= $_GET['delete'];
	  $mysqli->query("DELETE FROM comp_info WHERE comp_id=$comp_id") or die($mysqli->error());
	  
	  $_SESSION['message']="Record has been Deleted!";
	  $_SESSION['msg_type']= "danger";
	  
	  header("location: table_4.php");
  }
  
  
  if (isset($_GET['edit'])){
	  $comp_id = $_GET['edit'];
	  $update = true;
	  $result = $mysqli->query("SELECT * FROM comp_info WHERE comp_id=$comp_id") or die($mysqli->error());
	  
	 while($row = mysqli_fetch_array($result))
	 {
		  $model = $row['model'];
		  $memory_size= $row['memory_size'];
		  $storage_size= $row['storage_size'];
		  
	  }
	  
  }
  
  if (isset($_POST['update'])){
	  $comp_id = $_POST['comp_id'];
	  $model = $_POST['model'];
	  $memory_size = $_POST['memory_size'];
	  $storage_size = $_POST['storage_size'];
	  
	  $mysqli->query("UPDATE comp_info SET model='$model', memory_size='$memory_size', storage_size='$storage_size' WHERE comp_id=$comp_id")or
	                 die($mysqli->error());
					 
	 $_SESSION['message']="Record has been Updated!";
	  $_SESSION['msg_type']= "warning";
	  
	  header("location: table_4.php");
  }

?>