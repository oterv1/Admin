<?php

session_start();
// Password and User Changerd
 $mysqli = new mysqli('localhost','admin','Pa11word','deltaTeam') or die(mysqli_error($mysqli));
  
  $BuildingID=0;
  $update= false;
  $id=0;
  $count=0;
  $room_id=0;
  $comp_id=0;
  
 if (isset($_POST['add'])){
	 
	 $count=$_POST['count'];
	 $BuildingID=$_POST['BuildingID'];
	 $room_id = $_POST['room_id'];
	 $comp_id = $_POST['comp_id'];
	 
	 $mysqli->query("INSERT IGNORE INTO room_comp (count,BuildingID,room_id,comp_id) VALUES ('$count','$BuildingID','$room_id','$comp_id')") or
	                die($mysqli->error);
					
    $_SESSION['message']="Record has been Added!";
	$_SESSION['msg_type']= "success";
	
	header("location: table_3.php");
 }
  
  if (isset($_GET['delete'])){
	  $id= $_GET['delete'];
	  $mysqli->query("DELETE FROM room_comp WHERE id=$id") or die($mysqli->error());
	  
	  $_SESSION['message']="Record has been Deleted!";
	  $_SESSION['msg_type']= "danger";
	  
	  header("location: table_3.php");
  }
  
  
  if (isset($_GET['edit'])){
	  $id = $_GET['edit'];
	  $update = true;
	  $result = $mysqli->query("SELECT * FROM room_comp WHERE id=$id") or die($mysqli->error());
	  
	  while($row = mysqli_fetch_array($result))
	  {
		  $id = $row['id'];
		  $count= $row['count'];
	  }
	  
  }
  
  if (isset($_POST['update'])){
	  $id = $_POST['id'];
	  $count = $_POST['count'];
	  
	  $mysqli->query("UPDATE room_comp SET count='$count' WHERE id=$id")or
	                 die($mysqli->error());
					 
	 $_SESSION['message']="Record has been Updated!";
	  $_SESSION['msg_type']= "warning";
	  
	  header("location: table_3.php");
  }

?>