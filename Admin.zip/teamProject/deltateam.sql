-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 28, 2018 at 01:15 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `deltateam`
--

-- --------------------------------------------------------

--
-- Table structure for table `building_info`
--

CREATE TABLE `building_info` (
  `BuildingID` int(10) NOT NULL,
  `BuildingNO` int(20) NOT NULL,
  `BuildingName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `building_info`
--

INSERT INTO `building_info` (`BuildingID`, `BuildingNO`, `BuildingName`) VALUES
(5, 14, 'Computer Building'),
(7, 16, 'Comp Lab');

-- --------------------------------------------------------

--
-- Table structure for table `comp_info`
--

CREATE TABLE `comp_info` (
  `comp_id` int(10) NOT NULL,
  `model` varchar(20) NOT NULL,
  `memory_size` varchar(20) NOT NULL,
  `storage_size` varchar(20) NOT NULL,
  `vendor_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comp_info`
--

INSERT INTO `comp_info` (`comp_id`, `model`, `memory_size`, `storage_size`, `vendor_id`) VALUES
(4, 'HP Envy', '16GB', '1T', 6),
(6, 'Lenovo X-200', '12GB', '500GB', 7);

-- --------------------------------------------------------

--
-- Table structure for table `rooms_info`
--

CREATE TABLE `rooms_info` (
  `room_id` int(10) NOT NULL,
  `room_no` int(20) NOT NULL,
  `capacity` int(30) NOT NULL,
  `BuildingID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms_info`
--

INSERT INTO `rooms_info` (`room_id`, `room_no`, `capacity`, `BuildingID`) VALUES
(39, 5, 33, 5),
(40, 7, 38, 7);

-- --------------------------------------------------------

--
-- Table structure for table `room_comp`
--

CREATE TABLE `room_comp` (
  `id` int(10) NOT NULL,
  `count` int(30) NOT NULL,
  `room_id` int(10) NOT NULL,
  `BuildingID` int(10) NOT NULL,
  `comp_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_comp`
--

INSERT INTO `room_comp` (`id`, `count`, `room_id`, `BuildingID`, `comp_id`) VALUES
(8, 29, 39, 5, 4),
(9, 24, 40, 7, 6);

-- --------------------------------------------------------

--
-- Table structure for table `vendor_info`
--

CREATE TABLE `vendor_info` (
  `vendor_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendor_info`
--

INSERT INTO `vendor_info` (`vendor_id`, `name`, `contact`, `phone`) VALUES
(6, 'Michael Stainchiu', 'Nely Rubi, 407-505-98700, Wife', '407-768-9001'),
(7, 'Xi Hau Fen', 'Ho Chi Fen, 609-798-3009,father', '409-900-8761');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `building_info`
--
ALTER TABLE `building_info`
  ADD PRIMARY KEY (`BuildingID`);

--
-- Indexes for table `comp_info`
--
ALTER TABLE `comp_info`
  ADD PRIMARY KEY (`comp_id`),
  ADD KEY `vendor_id` (`vendor_id`);

--
-- Indexes for table `rooms_info`
--
ALTER TABLE `rooms_info`
  ADD PRIMARY KEY (`room_id`),
  ADD KEY `BuildingID` (`BuildingID`);

--
-- Indexes for table `room_comp`
--
ALTER TABLE `room_comp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `room_id` (`room_id`),
  ADD KEY `BuildingID` (`BuildingID`),
  ADD KEY `comp_id` (`comp_id`);

--
-- Indexes for table `vendor_info`
--
ALTER TABLE `vendor_info`
  ADD PRIMARY KEY (`vendor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `building_info`
--
ALTER TABLE `building_info`
  MODIFY `BuildingID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `comp_info`
--
ALTER TABLE `comp_info`
  MODIFY `comp_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `rooms_info`
--
ALTER TABLE `rooms_info`
  MODIFY `room_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `room_comp`
--
ALTER TABLE `room_comp`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `vendor_info`
--
ALTER TABLE `vendor_info`
  MODIFY `vendor_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comp_info`
--
ALTER TABLE `comp_info`
  ADD CONSTRAINT `comp_info_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendor_info` (`vendor_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rooms_info`
--
ALTER TABLE `rooms_info`
  ADD CONSTRAINT `rooms_info_ibfk_1` FOREIGN KEY (`BuildingID`) REFERENCES `building_info` (`BuildingID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `room_comp`
--
ALTER TABLE `room_comp`
  ADD CONSTRAINT `room_comp_ibfk_1` FOREIGN KEY (`room_id`) REFERENCES `rooms_info` (`room_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `room_comp_ibfk_2` FOREIGN KEY (`BuildingID`) REFERENCES `building_info` (`BuildingID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `room_comp_ibfk_3` FOREIGN KEY (`comp_id`) REFERENCES `comp_info` (`comp_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
